function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

$(document).ready(function() {




    if (!jQuery("#defaultOpen").length == 0) {
        document.getElementById("defaultOpen").click();
    }


    $("button.navbar-toggler").click(function() {
        jQuery("body").toggleClass("menuopen");
    });
    $(".video-poup-block .anchr-block").click(function() {
        $(".video-modal").addClass("open");
    });
    $(".video-modal .close").click(function() {
        $(".video-modal").removeClass("open");
    });

    $('#what-clients-say').owlCarousel({
        autoplay: true,
        autoplayTimeout: 1000,
        autoplayHoverPause: true,
        items: 3,
        loop: true,
        center: false,
        rewind: false,
        nav: false,

        mouseDrag: true,
        touchDrag: true,
        pullDrag: true,
        freeDrag: false,

        margin: 40,
        stagePadding: 0,

        merge: false,
        mergeFit: true,
        autoWidth: false,

        startPosition: 0,
        rtl: false,

        smartSpeed: 250,
        fluidSpeed: false,
        dragEndSpeed: false,
        responsive: {
            0: {
                items: 1
            },
            480: {
                items: 2
            },
            768: {
                items: 2,
                loop: false
            },
            992: {
                items: 3,
                loop: false
            },
            1024: {
                items: 3,
                loop: false
            }
        },
        responsiveRefreshRate: 200,
        responsiveBaseElement: window,

        fallbackEasing: 'swing',

        info: false,

        nestedItemSelector: false,
        itemElement: 'div',
        stageElement: 'div',

        refreshClass: 'owl-refresh',
        loadedClass: 'owl-loaded',
        loadingClass: 'owl-loading',
        rtlClass: 'owl-rtl',
        responsiveClass: 'owl-responsive',
        dragClass: 'owl-drag',
        itemClass: 'owl-item',
        stageClass: 'owl-stage',
        stageOuterClass: 'owl-stage-outer',
        grabClass: 'owl-grab',
        autoHeight: false,
        lazyLoad: false

    });
    $('#home-banner').owlCarousel({
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        items: 1,
        loop: true,
        nav: false,
        mouseDrag: false,
        margin: 0,
        stagePadding: 0,
        animateIn: 'fadeIn',
        animateOut: 'fadeOut',
        touchDrag: false
    });

    var owlDemo = $('#owl-demo');
    owlDemo.owlCarousel({
        items: 1,
        loop: true,
        nav: true,
        margin: 0,
        autoplay: true,
        autoplayTimeout: 50000,
        autoplayHoverPause: true,
        mouseDrag: false,
        touchDrag: false,
        stagePadding: 0,
        rewind: false,
        responsiveRefreshRate: 20000,
        checkVisible: false,
        animateIn: 'fadeIn'
    });

    var owl = $('#img-gallery-slider');
    owl.owlCarousel({
        stagePadding: 50,
        responsiveClass: true,
        autoWidth: true,
        autoplay: true,
        loop: true,
        margin: 20,
        center: true,
        slideTransition: 'linear',
        autoplayTimeout: 500,
        autoplaySpeed: 6000,
        fluidSpeed: true,
        smartSpeed: 6000,
        nav: false,
        autoplayHoverPause: true,
        responsive: {
            0: {
                margin: 6,
                loop: true
            },
            768: {
                stagePadding: 50,
                margin: 20,
            },
            1025: {
                margin: 20,
            },
            1360: {
                margin: 20,

            }
        }
    });
    owl.on('.img-gallery-slider-info changed.owl.carousel', function(event) {
        setTimeout(function() {
            owlDemo.trigger('stop.owl.autoplay');
            if (!$('.header-ht').hasClass('addedcode')) {
                var $carousel = jQuery('#img-gallery-slider');
                var carouselData = $carousel.data();
                var carouselOptions = carouselData['owl.carousel'].options;
                carouselOptions.autoplayTimeout = 6000;
                carouselOptions.autoplaySpeed = 6000;
                carouselOptions.smartSpeed = 6000;
                $carousel.trigger('refresh.owl.carousel');
                $('.header-ht').addClass('addedcode');
            }
        }, 100);
    });
    $('#home-banner-slide').owlCarousel({
        autoPlay: true,
        //autoplayTimeout:8000,
        //autoplayHoverPause:true,
        items: 1,
        loop: true,
        nav: false,
        margin: 0,
        stagePadding: 0,
        animateIn: 'fadeIn',
        responsive: {
            0: {
                items: 1
            },
            480: {
                items: 1
            },
            768: {
                items: 1
            },
            992: {
                items: 1
            },
            1024: {
                items: 1,
            }
        },

    });

    if ($(window).width() < 992) {
        $('.handle-every-transaction .owl-nav .owl-next').click(function() {
            owlDemo.trigger('stop.owl.autoplay');
            var angle = ($('#circleshap1').data('angle')) || 0;
            angle += 90;
            $('#circleshap1').css({ 'transform': 'rotate(' + angle + 'deg)' });
            $('#circleshap1').data('angle', angle);

        })

        $('.handle-every-transaction .owl-nav .owl-prev').click(function() {
            owlDemo.trigger('stop.owl.autoplay');
            var angle = ($('#circleshap1').data('angle')) || 0;
            angle -= 90;
            $('#circleshap1').css({ 'transform': 'rotate(' + angle + 'deg)' });
            $('#circleshap1').data('angle', angle);

        })
    } else {
        $('.handle-every-transaction .owl-nav .owl-next').click(function() {
            owlDemo.trigger('stop.owl.autoplay');
            var angle = ($('#circleshap').data('angle')) || 0;
            angle += 90;
            $('#circleshap').css({ 'transform': 'rotate(' + angle + 'deg)' });
            $('#circleshap').data('angle', angle);

        })

        $('.handle-every-transaction .owl-nav .owl-prev').click(function() {
            owlDemo.trigger('stop.owl.autoplay');
            var angle = ($('#circleshap').data('angle')) || 0;
            angle -= 90;
            $('#circleshap').css({ 'transform': 'rotate(' + angle + 'deg)' });
            $('#circleshap').data('angle', angle);

        })
    }

});

/**
 * Sticky header
 */

jQuery(document).on("scroll", function() {
    if (jQuery(document).scrollTop() > 0) {
        jQuery("header, body").addClass("header-fixed");
    } else {
        jQuery("header, body").removeClass("header-fixed");
    }
});
jQuery(document).ready(function() {
    jQuery("li.nav-item  span.plusminus").click(function() {
        jQuery(".sub-nav").slideToggle("2000");
        jQuery(this).toggleClass("active");
    });
});

jQuery(function($) {

    // Function which adds the 'animated' class to any '.animatable' in view
    var doAnimations = function() {

        // Calc current offset and get all animatables
        var offset = $(window).scrollTop() + $(window).height(),
            $animatables = $('.animatable');

        // Unbind scroll handler if we have no animatables
        if ($animatables.length == 0) {
            $(window).off('scroll', doAnimations);
        }

        // Check all animatables and animate them if necessary
        $animatables.each(function(i) {
            var $animatable = $(this);
            if (($animatable.offset().top + $animatable.height() - 20) < offset) {
                $animatable.removeClass('animatable').addClass('animated');
            }
        });

    };

    // Hook doAnimations on scroll, and trigger a scroll
    $(window).on('scroll', doAnimations);
    $(window).trigger('scroll');

});



(function($) {
    // the sameHeight functions makes all the selected elements of the same height
    $.fn.sameHeight = function() {
        var selector = this;
        var heights = [];

        // Save the heights of every element into an array
        selector.each(function() {
            var height = $(this).height();
            heights.push(height);
        });

        // Get the biggest height
        var maxHeight = Math.max.apply(null, heights);
        // Show in the console to verify
        // console.log(heights,maxHeight);

        // Set the maxHeight to every selected element
        selector.each(function() {
            $(this).height(maxHeight);
        });
    };

}(jQuery));
jQuery('.setting-option-row .block-box').sameHeight();
jQuery('#what-clients-say .item .contentbox').sameHeight();
jQuery('.setting-option-row .block-box .label-s-reg').sameHeight();


jQuery(document).ready(function($) {
    //set animation timing
    var animationDelay = 2500,
        //loading bar effect
        barAnimationDelay = 3800,
        barWaiting = barAnimationDelay - 3000, //3000 is the duration of the transition on the loading bar - set in the scss/css file
        //letters effect
        lettersDelay = 50,
        //type effect
        typeLettersDelay = 150,
        selectionDuration = 500,
        typeAnimationDelay = selectionDuration + 800,
        //clip effect 
        revealDuration = 600,
        revealAnimationDelay = 1500;

    initHeadline();


    function initHeadline() {
        //insert <i> element for each letter of a changing word
        singleLetters($('.cd-headline.letters').find('b'));
        //initialise headline animation
        animateHeadline($('.cd-headline'));
    }

    function singleLetters($words) {
        $words.each(function() {
            var word = $(this),
                letters = word.text().split(''),
                selected = word.hasClass('is-visible');
            for (i in letters) {
                if (word.parents('.rotate-2').length > 0) letters[i] = '<em>' + letters[i] + '</em>';
                letters[i] = (selected) ? '<i class="in">' + letters[i] + '</i>' : '<i>' + letters[i] + '</i>';
            }
            var newLetters = letters.join('');
            word.html(newLetters).css('opacity', 1);
        });
    }

    function animateHeadline($headlines) {
        var duration = animationDelay;
        $headlines.each(function() {
            var headline = $(this);

            if (headline.hasClass('loading-bar')) {
                duration = barAnimationDelay;
                setTimeout(function() { headline.find('.cd-words-wrapper').addClass('is-loading') }, barWaiting);
            } else if (headline.hasClass('clip')) {
                var spanWrapper = headline.find('.cd-words-wrapper'),
                    newWidth = spanWrapper.width() + 10
                spanWrapper.css('width', newWidth);
            } else if (!headline.hasClass('type')) {
                //assign to .cd-words-wrapper the width of its longest word
                var words = headline.find('.cd-words-wrapper b'),
                    width = 0;
                words.each(function() {
                    var wordWidth = $(this).width();
                    if (wordWidth > width) width = wordWidth;
                });
                headline.find('.cd-words-wrapper').css('width', width);
            };

            //trigger animation
            setTimeout(function() { hideWord(headline.find('.is-visible').eq(0)) }, duration);
        });
    }

    function hideWord($word) {
        var nextWord = takeNext($word);

        if ($word.parents('.cd-headline').hasClass('type')) {
            var parentSpan = $word.parent('.cd-words-wrapper');
            parentSpan.addClass('selected').removeClass('waiting');
            setTimeout(function() {
                parentSpan.removeClass('selected');
                $word.removeClass('is-visible').addClass('is-hidden').children('i').removeClass('in').addClass('out');
            }, selectionDuration);
            setTimeout(function() { showWord(nextWord, typeLettersDelay) }, typeAnimationDelay);

        } else if ($word.parents('.cd-headline').hasClass('letters')) {
            var bool = ($word.children('i').length >= nextWord.children('i').length) ? true : false;
            hideLetter($word.find('i').eq(0), $word, bool, lettersDelay);
            showLetter(nextWord.find('i').eq(0), nextWord, bool, lettersDelay);

        } else if ($word.parents('.cd-headline').hasClass('clip')) {
            $word.parents('.cd-words-wrapper').animate({ width: '2px' }, revealDuration, function() {
                switchWord($word, nextWord);
                showWord(nextWord);
            });

        } else if ($word.parents('.cd-headline').hasClass('loading-bar')) {
            $word.parents('.cd-words-wrapper').removeClass('is-loading');
            switchWord($word, nextWord);
            setTimeout(function() { hideWord(nextWord) }, barAnimationDelay);
            setTimeout(function() { $word.parents('.cd-words-wrapper').addClass('is-loading') }, barWaiting);

        } else {
            switchWord($word, nextWord);
            setTimeout(function() { hideWord(nextWord) }, animationDelay);
        }
    }

    function showWord($word, $duration) {
        if ($word.parents('.cd-headline').hasClass('type')) {
            showLetter($word.find('i').eq(0), $word, false, $duration);
            $word.addClass('is-visible').removeClass('is-hidden');

        } else if ($word.parents('.cd-headline').hasClass('clip')) {
            $word.parents('.cd-words-wrapper').animate({ 'width': $word.width() + 10 }, revealDuration, function() {
                setTimeout(function() { hideWord($word) }, revealAnimationDelay);
            });
        }
    }

    function hideLetter($letter, $word, $bool, $duration) {
        $letter.removeClass('in').addClass('out');

        if (!$letter.is(':last-child')) {
            setTimeout(function() { hideLetter($letter.next(), $word, $bool, $duration); }, $duration);
        } else if ($bool) {
            setTimeout(function() { hideWord(takeNext($word)) }, animationDelay);
        }

        if ($letter.is(':last-child') && $('html').hasClass('no-csstransitions')) {
            var nextWord = takeNext($word);
            switchWord($word, nextWord);
        }
    }

    function showLetter($letter, $word, $bool, $duration) {
        $letter.addClass('in').removeClass('out');

        if (!$letter.is(':last-child')) {
            setTimeout(function() { showLetter($letter.next(), $word, $bool, $duration); }, $duration);
        } else {
            if ($word.parents('.cd-headline').hasClass('type')) { setTimeout(function() { $word.parents('.cd-words-wrapper').addClass('waiting'); }, 200); }
            if (!$bool) { setTimeout(function() { hideWord($word) }, animationDelay) }
        }
    }

    function takeNext($word) {
        return (!$word.is(':last-child')) ? $word.next() : $word.parent().children().eq(0);
    }

    function takePrev($word) {
        return (!$word.is(':first-child')) ? $word.prev() : $word.parent().children().last();
    }

    function switchWord($oldWord, $newWord) {
        $oldWord.removeClass('is-visible').addClass('is-hidden');
        $newWord.removeClass('is-hidden').addClass('is-visible');
    }
});