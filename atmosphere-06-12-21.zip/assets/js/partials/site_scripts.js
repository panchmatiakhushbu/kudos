jQuery(document).ready(function() {
    jQuery("button.navbar-toggler").click(function() {
        jQuery("body").toggleClass("menuopen");
    });

    jQuery('#setting-sldier').owlCarousel({
        stagePadding: 50,
         responsiveClass:true,
        autoplay: true,
        loop: true,
        margin: 5,
        center:true,
         autoWidth:true,
        nav: false,
        responsive: {
            0: {
                items: 3,
                 stagePadding: 5,
            },
            600:{
                 items: 3,
                 stagePadding: 10,
            },
            1025: {
                items: 6,
                 stagePadding: 10,
            },
            1360: {
                items: 8,

            }

        }
    });

 



});

jQuery(function($) {
  
  // Function which adds the 'animated' class to any '.animatable' in view
  var doAnimations = function() {
    
    // Calc current offset and get all animatables
    var offset = $(window).scrollTop() + $(window).height(),
        $animatables = $('.animatable');
    
    // Unbind scroll handler if we have no animatables
    if ($animatables.length == 0) {
      $(window).off('scroll', doAnimations);
    }
    
    // Check all animatables and animate them if necessary
        $animatables.each(function(i) {
       var $animatable = $(this);
            if (($animatable.offset().top + $animatable.height() - 20) < offset) {
        $animatable.removeClass('animatable').addClass('animated');
            }
    });

    };
  
  // Hook doAnimations on scroll, and trigger a scroll
    $(window).on('scroll', doAnimations);
  $(window).trigger('scroll');

});

$(document).ready(function(){

    // Select and loop the container element of the elements you want to equalise
    $('.tab-pane').each(function(){  
      
      // Cache the highest
      var highestBox = 0;
      
      // Select and loop the elements you want to equalise
      $('.col-6 .contentbox', this).each(function(){
        
        // If this box is higher than the cached highest then store it
        if($(this).height() > highestBox) {
          highestBox = $(this).height(); 
        }
      
      });  
            
      // Set the height of all those children to whichever was highest 
      $('.col-6 .contentbox',this).height(highestBox);
                    
    }); 

});